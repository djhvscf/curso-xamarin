﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AgendaContacto.Model
{
    public class Contacto
    {
        public string Nombre { get; set; }

        public string Telefono { get; set; }

        public string Direccion { get; set; }
    }
}
